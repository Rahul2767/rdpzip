import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import mysql.connector
from mysql.connector import Error
import threading
import queue
import time
import logging
from fake_useragent import UserAgent
from functools import wraps
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scrp.log'),  # changed from scraper.log
        logging.StreamHandler()
    ]
)

# Configuration settings
BASE_URL = 'https://bunkr-albums.io/'
START_PAGE = 1
END_PAGE = 19447
MAX_THREADS = 20
MAX_RETRIES = 3
RETRY_DELAY = 2
LINK_BATCH_SIZE = 100
LINK_WORKER_THREADS = 10

# MySQL configuration with SSL
DB_CONFIG = {
    'host': 'coomer-db-rahuldhiman3855-25e2.j.aivencloud.com',
    'port': 22652,
    'user': 'avnadmin',
    'password': 'AVNS_hIUOlyrjQ6aJw2oadb0',
    'database': 'defaultdb',
    'ssl_ca': './ca.pem',
    'ssl_verify_cert': False
}

page_queue = queue.Queue()
db_queue = queue.Queue()
ua = UserAgent()
scraped_counter = threading.Lock()
total_scraped_pages = 0
link_queue = queue.Queue()


def retry_on_failure(max_retries=MAX_RETRIES, delay=RETRY_DELAY):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    retries += 1
                    if retries < max_retries:
                        logging.warning(f"Attempt {retries} failed for {func.__name__}. Retrying in {delay} seconds... Error: {str(e)}")
                        time.sleep(delay)
                    else:
                        logging.error(f"Max retries ({max_retries}) exceeded for {func.__name__}")
                        raise
        return wrapper
    return decorator


def create_database_connection():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            return connection
    except Error as e:
        logging.error(f"Error connecting to MySQL: {e}")
        return None


def initialize_database():
    try:
        logging.info("Started database connection")
        connection = create_database_connection()
        if connection:
            cursor = connection.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS albums (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255),
                    file_count VARCHAR(50),
                    link VARCHAR(512),
                    page_number INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_link (link)
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scraping_log (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    page_number INT UNIQUE,
                    status VARCHAR(50),
                    error_message TEXT,
                    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            connection.commit()
            cursor.close()
            connection.close()
            logging.info("Database initialized successfully")
    except Error as e:
        logging.error(f"Error initializing database: {e}")


@retry_on_failure()
def scrape_page(page_number):
    url = f"{BASE_URL}?page={page_number}"
    headers = {'User-Agent': ua.random}
    response = requests.get(url, headers=headers, timeout=10)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    items = soup.select('.group\\/item')
    scraped_data = []

    for item in items:
        try:
            title_elem = item.select_one('.truncate')
            title = title_elem.get_text(strip=True) if title_elem else None
            file_count_elem = item.select_one('p.text-xs .font-semibold')
            file_count = file_count_elem.get_text(strip=True) if file_count_elem else None
            link_elem = item.select_one('a')
            link = urljoin(BASE_URL, link_elem['href']) if link_elem and 'href' in link_elem.attrs else None

            if title and link:
                scraped_data.append({
                    'title': title,
                    'file_count': file_count,
                    'link': link,
                    'page_number': page_number
                })
        except Exception as e:
            logging.error(f"Error processing item on page {page_number}: {e}")

    return scraped_data


def worker():
    global total_scraped_pages
    while True:
        page_number = page_queue.get()
        if page_number is None:
            break
        try:
            data = scrape_page(page_number)
            if data:
                db_queue.put(data)
                logging.info(f"Successfully scraped page {page_number} with {len(data)} items")
            # log_scraping_status(page_number, "success")
        except Exception as e:
            logging.error(f"Failed to scrape page {page_number}: {e}")
            # log_scraping_status(page_number, "failed", str(e))
        finally:
            with scraped_counter:
                total_scraped_pages += 1
                if total_scraped_pages % 50 == 0:
                    logging.info(f"Progress: {total_scraped_pages} pages scraped so far.")
            page_queue.task_done()


def log_scraping_status(page_number, status, error_message=None):
    try:
        connection = create_database_connection()
        if connection:
            cursor = connection.cursor()
            cursor.execute("""
                INSERT INTO scraping_log (page_number, status, error_message)
                VALUES (%s, %s, %s)
                ON DUPLICATE KEY UPDATE
                status = VALUES(status),
                error_message = VALUES(error_message),
                scraped_at = CURRENT_TIMESTAMP
            """, (page_number, status, error_message))
            connection.commit()
            cursor.close()
            connection.close()
    except Error as e:
        logging.error(f"Error logging scraping status for page {page_number}: {e}")


def db_worker():
    connection = create_database_connection()
    if not connection:
        logging.error("Database worker failed to connect to MySQL")
        return
    cursor = connection.cursor()
    try:
        while True:
            data_batch = db_queue.get()
            if data_batch is None:
                break
            try:
                values = [(
                    item['title'],
                    item['file_count'],
                    item['link'],
                    item['page_number']
                ) for item in data_batch]
                cursor.executemany("""
                    INSERT IGNORE INTO albums (title, file_count, link, page_number)
                    VALUES (%s, %s, %s, %s)
                """, values)
                connection.commit()
                logging.info(f"Inserted/updated {len(data_batch)} records")
                if db_queue.qsize() % 100 == 0:
                    logging.info(f"Database queue remaining: {db_queue.qsize()} batches.")
            except Error as e:
                connection.rollback()
                logging.error(f"Database error: {e}")
            finally:
                db_queue.task_done()
    finally:
        cursor.close()
        connection.close()


def get_last_scraped_page():
    try:
        connection = create_database_connection()
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT MAX(page_number) FROM scraping_log WHERE status = 'success'")
            result = cursor.fetchone()
            cursor.close()
            connection.close()
            return result[0] if result[0] is not None else 0
    except Error as e:
        logging.error(f"Error getting last scraped page: {e}")
        return 0


def main():
    logging.info("Started Scraper")
    initialize_database()
    last_scraped_page = get_last_scraped_page()
    start_page = max(START_PAGE, last_scraped_page + 1)
    estimated_pages = END_PAGE - start_page + 1
    logging.info(f"Starting scraping from page {start_page} to {END_PAGE}")
    logging.info(f"Estimated total pages to scrape: {estimated_pages}")

    db_thread = threading.Thread(target=db_worker)
    db_thread.start()

    threads = []
    for _ in range(MAX_THREADS):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)

    for page in range(start_page, END_PAGE + 1):
        page_queue.put(page)

    page_queue.join()

    for _ in range(MAX_THREADS):
        page_queue.put(None)
    for t in threads:
        t.join()

    db_queue.put(None)
    db_thread.join()
    logging.info("Scraping completed!")

LINK_BATCH_SIZE = 100
LINK_WORKER_THREADS = 10
link_queue = queue.Queue()


@retry_on_failure()
def scrape_album_details(link):
    try:
        headers = {'User-Agent': ua.random}
        response = requests.get(link, headers=headers, timeout=10)

        if response.status_code == 404:
            return {'title': None, 'size_and_files': None, 'views': 'not having'}

        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')

        title = soup.select_one('h1.truncate')
        size_and_files = soup.select_one('p.visitors span.font-semibold')
        views = soup.select_one('#viewCount')

        return {
            'title': title.get_text(strip=True) if title else None,
            'size_and_files': size_and_files.get_text(strip=True) if size_and_files else None,
            'views': views.get_text(strip=True) if views else 'not having'
        }

    except requests.exceptions.RequestException as e:
        logging.warning(f"Request failed for {link}: {e}")
        return {'title': None, 'size_and_files': None, 'views': 'not having'}



def link_worker():
    connection = create_database_connection()
    if not connection:
        logging.error("Link worker failed to connect to MySQL")
        return
    cursor = connection.cursor()
    try:
        while True:
            album = link_queue.get()
            if album is None:
                break
            try:
                details = scrape_album_details(album['link'])
                if details:
                    cursor.execute("""
                        UPDATE albums
                        SET updated_title = %s,
                            size_and_files = %s,
                            views = %s
                        WHERE link = %s
                    """, (
                        details['title'],
                        details['size_and_files'],
                        details['views'],
                        album['link']
                    ))
                    connection.commit()
                    logging.info(f"Updated album {album['link']}")
            except Exception as e:
                logging.error(f"Error updating album {album['link']}: {e}")
            finally:
                link_queue.task_done()
    finally:
        cursor.close()
        connection.close()


def update_album_details():
    logging.info("Started Album Details Updater")
    batch_size = 1000
    total_updated = 0

    start = 10660
    end = 13660

    while start <= end:
        connection = create_database_connection()
        if not connection:
            logging.error("DB connection failed. Retrying...")
            time.sleep(5)
            continue

        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT id, link FROM albums
            WHERE views IS NULL AND page_number IS %s
            ORDER BY id ASC
        """, (start,))
        rows = cursor.fetchall()
        cursor.close()
        connection.close()

        start += 1

        if not rows:
            break  # All links processed

        logging.info(f"Processing batch of {len(rows)} links")

        with ThreadPoolExecutor(max_workers=LINK_WORKER_THREADS) as executor:
            futures = {
                executor.submit(process_album_detail, row): row['id']
                for row in rows
            }
            for future in as_completed(futures):
                album_id = futures[future]
                try:
                    future.result()
                    total_updated += 1
                    if total_updated % 100 == 0:
                        logging.info(f"Total updated: {total_updated}")
                except Exception as e:
                    logging.error(f"Error processing album ID {album_id}: {e}")

    logging.info(f"All albums updated. Total processed: {total_updated}")


def process_album_detail(album):
    details = scrape_album_details(album['link'])
    if not details:
        return

    connection = create_database_connection()
    if not connection:
        raise Exception("DB connection failed in thread")

    cursor = connection.cursor()
    try:
        cursor.execute("""
            UPDATE albums
            SET updated_title = %s,
                size_and_files = %s,
                views = %s
            WHERE id = %s
        """, (
            details['title'],
            details['size_and_files'],
            details['views'],
            album['id']
        ))
        connection.commit()
    finally:
        cursor.close()
        connection.close()






if __name__ == "__main__":
    # main()
    update_album_details()





